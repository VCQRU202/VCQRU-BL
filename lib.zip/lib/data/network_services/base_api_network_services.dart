abstract class BaseApiServices {
  Future<dynamic> postAPI(var data,String url) ;
}