library values;

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


part 'colors.dart';
part 'borders.dart';
part 'sizes.dart';
part 'strings.dart';

part 'gradients.dart';
part 'decoration.dart';