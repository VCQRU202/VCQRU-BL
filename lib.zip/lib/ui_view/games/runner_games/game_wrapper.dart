import 'package:flame/flame.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nes_ui/nes_ui.dart';
import 'package:provider/provider.dart';

import 'app_lifecycle/app_lifecycle.dart';
import 'audio/audio_controller.dart';
import 'player_progress/player_progress.dart';
import 'router.dart';
import 'settings/settings.dart';
import 'style/palette.dart';

final navigatorKey = GlobalKey<NavigatorState>();

class GameWrapper extends StatelessWidget {
  const GameWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return AppLifecycleObserver(
      child: AppProviders(),
    );
  }
}

class AppProviders extends StatelessWidget {
  const AppProviders({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider(create: (context) => Palette()),
        ChangeNotifierProvider(create: (context) => PlayerProgress()),
        Provider(create: (context) => SettingsController()),
        ProxyProvider2<SettingsController, AppLifecycleStateNotifier,
            AudioController>(
          lazy: false,
          create: (context) => AudioController(),
          update: (context, settings, lifecycleNotifier, audio) {
            audio!.attachDependencies(lifecycleNotifier, settings);
            return audio;
          },
          dispose: (context, audio) => audio.dispose(),
        ),
      ],
      child: ButtonGame(),
    );
  }
}

class ButtonGame extends StatelessWidget {
  const ButtonGame({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              FilledButton(
                onPressed: () {
                  navigatorKey.currentState!.push(
                    MaterialPageRoute(builder: (context) => MyGame()),
                  );
                },
                child: Text('Play Game'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MyGame extends StatelessWidget {
  const MyGame({super.key});

  @override
  Widget build(BuildContext context) {
    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   SystemChrome.setPreferredOrientations([
    //     DeviceOrientation.landscapeRight,
    //     DeviceOrientation.landscapeLeft,
    //   ]);
    // });
    return MultiProvider(
      providers: [
        Provider(create: (context) => Palette()),
        ChangeNotifierProvider(create: (context) => PlayerProgress()),
        Provider(create: (context) => SettingsController()),
        ProxyProvider2<SettingsController, AppLifecycleStateNotifier,
            AudioController>(
          lazy: false,
          create: (context) => AudioController(),
          update: (context, settings, lifecycleNotifier, audio) {
            audio!.attachDependencies(lifecycleNotifier, settings);
            return audio;
          },
          dispose: (context, audio) => audio.dispose(),
        ),
      ],
      child: Builder(builder: (context) {
        final palette = context.watch<Palette>();

        return Container(
          child: MaterialApp.router(
            title: 'Endless Runner',
            theme: flutterNesTheme().copyWith(
              colorScheme: ColorScheme.fromSeed(
                seedColor: palette.seed.color,
                surface: palette.backgroundMain.color,
              ),
              textTheme: GoogleFonts.pressStart2pTextTheme().apply(
                bodyColor: palette.text.color,
                displayColor: palette.text.color,
              ),
            ),
            routerConfig: router,
          ),
        );
      }),
    );
  }
}