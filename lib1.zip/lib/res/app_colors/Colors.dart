import 'dart:ui';
class MyAppColor{
  //new
  static const DashboardRed=Color(0xFF0D3F87);
  static const DashWhite1 =   Color(0xFFFFFFFF);
  static const PointsDash1=Color(0xFFFAA300);
  static const PointsDash=Color(0xFFffea94);
  static const HistoryRed=Color(0xFFFFE9E9);
  static const DashboardGreen=Color(0xFF0F4899);


  //text color
  static const TextBalck=     Color(0xFF000000);
  static const TextWhite=     Color(0xFFFFFFFF);
  static const TextWhite1=     Color(0xFFC7C5C5);
  static const TextRed=     Color(0xFF0D3F87);
  static const TextRed2=     Color(0xFFD7E4FA);

  //text-form
  static const formFillClr=Color(0xFFE5E9FF);
  static const formTextClr=     Color(0xFF0D3F87);
}