
import 'package:flutter/material.dart';

class ImagesAssets{

  static var Logo_app=Image.asset('assets/logo4.png');
  static var LOGIN_PASS_LOGO=AssetImage("assets/logo4.png");
  static var OTP_TOP=AssetImage("assets/otp_top.png");
  static var coin_image=Image.asset('assets/coin.png');
  static const dashboard_image_verified= "assets/verified.png";
  static const dashboard_loyality_imgage="loyalty.png";
  static const dashboard_loyalty_image= 'loyalty.png';
  static const dashboard_fake_product_image="fake_product.png";
  static const refer_image="refer_earn.png";


  static const dashboard_wallet_image="wallet.png";

  static const dashboard_ekyc_image='ekyc.png';
  static const dashboard_medal_image='medal.png';


  static const dashboard_history_image="history.png";
  static const blog_image="Blog.png";
  static const catlog_image="Catalogue.png";
  static const help_image="Help.png";
  static const brocher_image="Brochure.png";
  static const code_check_image="Code_details.png";

  static const dashboard_warranty_image="warrenty.png";
  static const dashboard_image_Scanner="assets/scanner.png";
  static const dashboard_claim_image="claim_history.png";
  static const asset='assets/';
}