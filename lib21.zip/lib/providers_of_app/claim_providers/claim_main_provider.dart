import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

import '../../data/repositorys/repositories_app.dart';
import '../../models/claim/claim_main_model.dart';
import '../../res/api_url/api_url.dart';
import '../../res/shared_preferences.dart';

class CliamMainProvider with ChangeNotifier{
  final _api = RepositoriesApp();
  ClaimMainModel? _historyData;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  ClaimMainModel? get historyData => _historyData;
  bool get isLoading => _isLoading;
  bool get hasError => _hasError;
  String get errorMessage => _errorMessage;


  CliamMainProvider() {
    getClaimMainData();
  }

  Future<void> getClaimMainData() async {
    _isLoading = true;
    _hasError = false;
    var m_Consumerid = await SharedPrefHelper().get("M_Consumerid");
    String m_c=m_Consumerid.toString();

    Map requestData = {
      "Comp_ID":AppUrl.Comp_ID,
    };
    print(requestData);
    try {
      final response = await _api.postRequest(requestData, AppUrl.CLIAM_MAIN);
      print(response);
      print("-------");
      print(response['success']);
      if (response['success']) {
        print("-----------true---");
        _isLoading = true;
        _hasError = false;
        _historyData=ClaimMainModel.fromJson(response);
      } else {
        print("-----------false---");
        _isLoading = false;
        _hasError = true;
        _errorMessage =response['message'];
        notifyListeners();
      }
    } catch (error) {
      _isLoading = false;
      _hasError = true;
      _errorMessage = "'Something Went Wrong' Please Try Again Later1";
      print('Failed to load profile');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  Future<void> retryFetchClaimMainData() async {
    _isLoading = true;
    _hasError = false;
    notifyListeners();
    await getClaimMainData();
  }
  int? selectedOption; // State variable for selected radio button
  Map<int, bool> subtitleVisibility = {}; // Track visibility of subtitles

  void selectOption(int index) {
    selectedOption = index;
    subtitleVisibility.clear();
    subtitleVisibility[index] = true; // Show only the selected subtitle
    notifyListeners();
  }

  void confirmSelection(BuildContext context, List<String> radioOptions) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Option selected: ${radioOptions[selectedOption!]}'),
      ),
    );
  }
}
