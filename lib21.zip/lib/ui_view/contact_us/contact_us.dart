import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers_of_app/splash_screen_provider/splash_screen_provider.dart';
class ContactUs extends StatefulWidget {
  const ContactUs({super.key});

  @override
  State<ContactUs> createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  @override
  Widget build(BuildContext context) {
    var orientation = MediaQuery.of(context).orientation;
    final splashProvider = Provider.of<SplashScreenProvider>(context, listen: false);
    return Scaffold(
      appBar: AppBar(
        title:  Text('Contact Us',style: TextStyle(color: Colors.white),),
        centerTitle: true,
        backgroundColor: splashProvider.color_bg,
        foregroundColor: Colors.black,
        iconTheme: IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFEDE7F6), Color(0xFFF3E5F5)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: SizedBox(
            height: 800,
            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom:
                  orientation == Orientation.landscape ? 500 : 400,
                  child: Container(
                    decoration:  BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          splashProvider.color_bg.withOpacity(1.0),
                          splashProvider.color_bg.withOpacity(1.0),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                    child: Container(
                      margin: EdgeInsets.only(top: 0),
                      child: Column(
                        children: [
                          Image.asset("assets/contact_us.png",height:
                          orientation == Orientation.landscape ? 150 : 280 ,)
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: orientation == Orientation.landscape ? 230 : 280,
                  left: 10,
                  right: 10,
                  child: GetInTouch(),
                ),
                Positioned(
                    top: orientation == Orientation.landscape ? 450 : 580, left: 10, right: 10, child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Center(child: Text("www.vcqru.com")),
                  ],
                ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
class GetInTouch extends StatelessWidget {
  const GetInTouch({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30), color: Colors.white),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "GET IN TOUCH!",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Color(0xff474747),
                  ),
                ),
              ],
            ),
            SizedBox(

              height: 10,
            ),
            Text(
              "Mobile Number",
              style: TextStyle(color: Colors.blueGrey),
            ),
            Text(
              "9958644640",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Divider(),
            Text(
              "Email",
              style: TextStyle(color: Colors.blueGrey),
            ),
            Text(
              "vcqru@vcqru.com",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Divider(),
            Text(
              "Location",
              style: TextStyle(color: Colors.blueGrey),
            ),
            Text(
              "Unit- 1502-1503, Tower 4, DLF CORPORATE GREENS, Sector74A, Narsinghpur, Gurugram, Haryana 122004",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
